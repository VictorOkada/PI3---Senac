﻿
namespace PI3
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.arquivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.restaurarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.maximizarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.minimizarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fecharToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listarPartidasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listarJogadoreToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.criarPartidaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.criarPartidaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.entrarEmUmaPartidaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.iniciarPartidaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.entrarEmUmaPartidaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sobreToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.versãoDLLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.errorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.lblDLL = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.pcBoxJ1T2 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ1T3 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ1T4 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ1T5 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ1T6 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ1T7 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ1T8 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ1T9 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ1T10 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ1T11 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ1T12 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ2T2 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ2T3 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ2T4 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ2T5 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ2T6 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ2T7 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ2T8 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ2T9 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ2T10 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ2T11 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ2T12 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ3T2 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ3T3 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ3T4 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ3T5 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ3T6 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ3T7 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ3T8 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ3T9 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ3T10 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ3T11 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ3T12 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ4T2 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ4T3 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ4T4 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ4T5 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ4T6 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ4T7 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ4T8 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ4T9 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ4T10 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ4T11 = new System.Windows.Forms.PictureBox();
            this.pcBoxJ4T12 = new System.Windows.Forms.PictureBox();
            this.picDado1 = new System.Windows.Forms.PictureBox();
            this.picDado2 = new System.Windows.Forms.PictureBox();
            this.picDado3 = new System.Windows.Forms.PictureBox();
            this.picDado4 = new System.Windows.Forms.PictureBox();
            this.picDado5 = new System.Windows.Forms.PictureBox();
            this.picDado6 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.pictureBox19 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox20 = new System.Windows.Forms.PictureBox();
            this.pictureBox21 = new System.Windows.Forms.PictureBox();
            this.pictureBox22 = new System.Windows.Forms.PictureBox();
            this.pictureBox23 = new System.Windows.Forms.PictureBox();
            this.pictureBox24 = new System.Windows.Forms.PictureBox();
            this.pictureBox25 = new System.Windows.Forms.PictureBox();
            this.pictureBox26 = new System.Windows.Forms.PictureBox();
            this.pictureBox27 = new System.Windows.Forms.PictureBox();
            this.lblC1 = new System.Windows.Forms.Label();
            this.lblC2 = new System.Windows.Forms.Label();
            this.lblC3 = new System.Windows.Forms.Label();
            this.pictureBox28 = new System.Windows.Forms.PictureBox();
            this.pictureBox29 = new System.Windows.Forms.PictureBox();
            this.pictureBox30 = new System.Windows.Forms.PictureBox();
            this.pictureBox31 = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lblERRO = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ1T2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ1T3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ1T4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ1T5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ1T6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ1T7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ1T8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ1T9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ1T10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ1T11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ1T12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ2T2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ2T3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ2T4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ2T5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ2T6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ2T7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ2T8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ2T9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ2T10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ2T11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ2T12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ3T2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ3T3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ3T4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ3T5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ3T6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ3T7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ3T8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ3T9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ3T10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ3T11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ3T12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ4T2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ4T3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ4T4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ4T5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ4T6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ4T7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ4T8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ4T9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ4T10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ4T11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ4T12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDado1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDado2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDado3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDado4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDado5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDado6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox31)).BeginInit();
            this.SuspendLayout();
            // 
            // listBox1
            // 
            this.listBox1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.listBox1.Cursor = System.Windows.Forms.Cursors.Default;
            this.listBox1.Font = new System.Drawing.Font("Britannic Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox1.ForeColor = System.Drawing.SystemColors.InfoText;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.HorizontalScrollbar = true;
            this.listBox1.ItemHeight = 15;
            this.listBox1.Location = new System.Drawing.Point(12, 167);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(182, 109);
            this.listBox1.TabIndex = 1;
            // 
            // arquivoToolStripMenuItem
            // 
            this.arquivoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.restaurarToolStripMenuItem,
            this.maximizarToolStripMenuItem,
            this.minimizarToolStripMenuItem,
            this.fecharToolStripMenuItem});
            this.arquivoToolStripMenuItem.Name = "arquivoToolStripMenuItem";
            this.arquivoToolStripMenuItem.Size = new System.Drawing.Size(70, 20);
            this.arquivoToolStripMenuItem.Text = "Arquivo";
            // 
            // restaurarToolStripMenuItem
            // 
            this.restaurarToolStripMenuItem.Name = "restaurarToolStripMenuItem";
            this.restaurarToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.restaurarToolStripMenuItem.Text = "Restaurar";
            this.restaurarToolStripMenuItem.Click += new System.EventHandler(this.restaurarToolStripMenuItem_Click);
            // 
            // maximizarToolStripMenuItem
            // 
            this.maximizarToolStripMenuItem.Name = "maximizarToolStripMenuItem";
            this.maximizarToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.maximizarToolStripMenuItem.Text = "Maximizar";
            this.maximizarToolStripMenuItem.Click += new System.EventHandler(this.maximizarToolStripMenuItem_Click);
            // 
            // minimizarToolStripMenuItem
            // 
            this.minimizarToolStripMenuItem.Name = "minimizarToolStripMenuItem";
            this.minimizarToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.minimizarToolStripMenuItem.Text = "Minimizar";
            this.minimizarToolStripMenuItem.Click += new System.EventHandler(this.minimizarToolStripMenuItem_Click);
            // 
            // fecharToolStripMenuItem
            // 
            this.fecharToolStripMenuItem.Name = "fecharToolStripMenuItem";
            this.fecharToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.fecharToolStripMenuItem.Text = "Fechar";
            this.fecharToolStripMenuItem.Click += new System.EventHandler(this.fecharToolStripMenuItem_Click);
            // 
            // menuToolStripMenuItem
            // 
            this.menuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.listarPartidasToolStripMenuItem,
            this.listarJogadoreToolStripMenuItem});
            this.menuToolStripMenuItem.Name = "menuToolStripMenuItem";
            this.menuToolStripMenuItem.Size = new System.Drawing.Size(55, 20);
            this.menuToolStripMenuItem.Text = "Menu";
            // 
            // listarPartidasToolStripMenuItem
            // 
            this.listarPartidasToolStripMenuItem.Name = "listarPartidasToolStripMenuItem";
            this.listarPartidasToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.listarPartidasToolStripMenuItem.Text = "Listar Partidas";
            this.listarPartidasToolStripMenuItem.Click += new System.EventHandler(this.listarPartidasToolStripMenuItem_Click);
            // 
            // listarJogadoreToolStripMenuItem
            // 
            this.listarJogadoreToolStripMenuItem.Name = "listarJogadoreToolStripMenuItem";
            this.listarJogadoreToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.listarJogadoreToolStripMenuItem.Text = "Listar Jogadores";
            this.listarJogadoreToolStripMenuItem.Click += new System.EventHandler(this.listarJogadoreToolStripMenuItem_Click);
            // 
            // criarPartidaToolStripMenuItem
            // 
            this.criarPartidaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.criarPartidaToolStripMenuItem1,
            this.entrarEmUmaPartidaToolStripMenuItem1,
            this.iniciarPartidaToolStripMenuItem});
            this.criarPartidaToolStripMenuItem.Name = "criarPartidaToolStripMenuItem";
            this.criarPartidaToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.criarPartidaToolStripMenuItem.Text = "Partida";
            // 
            // criarPartidaToolStripMenuItem1
            // 
            this.criarPartidaToolStripMenuItem1.Name = "criarPartidaToolStripMenuItem1";
            this.criarPartidaToolStripMenuItem1.Size = new System.Drawing.Size(225, 22);
            this.criarPartidaToolStripMenuItem1.Text = "Criar Partida";
            this.criarPartidaToolStripMenuItem1.Click += new System.EventHandler(this.criarPartidaToolStripMenuItem1_Click);
            // 
            // entrarEmUmaPartidaToolStripMenuItem1
            // 
            this.entrarEmUmaPartidaToolStripMenuItem1.Name = "entrarEmUmaPartidaToolStripMenuItem1";
            this.entrarEmUmaPartidaToolStripMenuItem1.Size = new System.Drawing.Size(225, 22);
            this.entrarEmUmaPartidaToolStripMenuItem1.Text = "Entrar em uma Partida";
            this.entrarEmUmaPartidaToolStripMenuItem1.Click += new System.EventHandler(this.entrarEmUmaPartidaToolStripMenuItem1_Click);
            // 
            // iniciarPartidaToolStripMenuItem
            // 
            this.iniciarPartidaToolStripMenuItem.Name = "iniciarPartidaToolStripMenuItem";
            this.iniciarPartidaToolStripMenuItem.Size = new System.Drawing.Size(225, 22);
            this.iniciarPartidaToolStripMenuItem.Text = "Iniciar Partida";
            this.iniciarPartidaToolStripMenuItem.Click += new System.EventHandler(this.iniciarPartidaToolStripMenuItem_Click);
            // 
            // entrarEmUmaPartidaToolStripMenuItem
            // 
            this.entrarEmUmaPartidaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sobreToolStripMenuItem,
            this.versãoDLLToolStripMenuItem});
            this.entrarEmUmaPartidaToolStripMenuItem.Name = "entrarEmUmaPartidaToolStripMenuItem";
            this.entrarEmUmaPartidaToolStripMenuItem.Size = new System.Drawing.Size(57, 20);
            this.entrarEmUmaPartidaToolStripMenuItem.Text = "Ajuda";
            // 
            // sobreToolStripMenuItem
            // 
            this.sobreToolStripMenuItem.Name = "sobreToolStripMenuItem";
            this.sobreToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.sobreToolStripMenuItem.Text = "Sobre...";
            this.sobreToolStripMenuItem.Click += new System.EventHandler(this.sobreToolStripMenuItem_Click);
            // 
            // versãoDLLToolStripMenuItem
            // 
            this.versãoDLLToolStripMenuItem.Name = "versãoDLLToolStripMenuItem";
            this.versãoDLLToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.versãoDLLToolStripMenuItem.Text = "Versão DLL...";
            this.versãoDLLToolStripMenuItem.Click += new System.EventHandler(this.versãoDLLToolStripMenuItem_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.menuStrip1.Font = new System.Drawing.Font("Britannic Bold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.arquivoToolStripMenuItem,
            this.menuToolStripMenuItem,
            this.criarPartidaToolStripMenuItem,
            this.entrarEmUmaPartidaToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1183, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.SystemColors.HotTrack;
            this.textBox2.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBox2.Location = new System.Drawing.Point(12, 37);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(37, 20);
            this.textBox2.TabIndex = 4;
            this.textBox2.Text = "Nome: ";
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.SystemColors.HotTrack;
            this.textBox3.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBox3.Location = new System.Drawing.Point(12, 63);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(46, 20);
            this.textBox3.TabIndex = 5;
            this.textBox3.Text = "Senha:";
            // 
            // textBox4
            // 
            this.textBox4.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBox4.Location = new System.Drawing.Point(55, 63);
            this.textBox4.Name = "textBox4";
            this.textBox4.PasswordChar = '*';
            this.textBox4.Size = new System.Drawing.Size(100, 20);
            this.textBox4.TabIndex = 6;
            // 
            // textBox5
            // 
            this.textBox5.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBox5.Location = new System.Drawing.Point(46, 37);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(109, 20);
            this.textBox5.TabIndex = 7;
            // 
            // errorProvider
            // 
            this.errorProvider.ContainerControl = this;
            // 
            // listBox2
            // 
            this.listBox2.BackColor = System.Drawing.SystemColors.HotTrack;
            this.listBox2.Font = new System.Drawing.Font("Britannic Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox2.ForeColor = System.Drawing.SystemColors.InfoText;
            this.listBox2.FormattingEnabled = true;
            this.listBox2.ItemHeight = 15;
            this.listBox2.Location = new System.Drawing.Point(12, 282);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(182, 109);
            this.listBox2.TabIndex = 8;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.textBox1.Location = new System.Drawing.Point(12, 141);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(143, 20);
            this.textBox1.TabIndex = 9;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.SystemColors.HotTrack;
            this.textBox6.Location = new System.Drawing.Point(12, 89);
            this.textBox6.Name = "textBox6";
            this.textBox6.ReadOnly = true;
            this.textBox6.Size = new System.Drawing.Size(143, 20);
            this.textBox6.TabIndex = 11;
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.SystemColors.HotTrack;
            this.textBox7.Location = new System.Drawing.Point(12, 115);
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(143, 20);
            this.textBox7.TabIndex = 12;
            // 
            // lblDLL
            // 
            this.lblDLL.AutoSize = true;
            this.lblDLL.Location = new System.Drawing.Point(801, 428);
            this.lblDLL.Name = "lblDLL";
            this.lblDLL.Size = new System.Drawing.Size(0, 13);
            this.lblDLL.TabIndex = 13;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(446, 27);
            this.textBox8.Multiline = true;
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(124, 46);
            this.textBox8.TabIndex = 18;
            // 
            // pcBoxJ1T2
            // 
            this.pcBoxJ1T2.Location = new System.Drawing.Point(426, 708);
            this.pcBoxJ1T2.Name = "pcBoxJ1T2";
            this.pcBoxJ1T2.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ1T2.TabIndex = 41;
            this.pcBoxJ1T2.TabStop = false;
            this.pcBoxJ1T2.Visible = false;
            // 
            // pcBoxJ1T3
            // 
            this.pcBoxJ1T3.Location = new System.Drawing.Point(446, 708);
            this.pcBoxJ1T3.Name = "pcBoxJ1T3";
            this.pcBoxJ1T3.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ1T3.TabIndex = 42;
            this.pcBoxJ1T3.TabStop = false;
            this.pcBoxJ1T3.Visible = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(406, 76);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(761, 687);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 29;
            this.pictureBox1.TabStop = false;
            // 
            // pcBoxJ1T4
            // 
            this.pcBoxJ1T4.Location = new System.Drawing.Point(466, 708);
            this.pcBoxJ1T4.Name = "pcBoxJ1T4";
            this.pcBoxJ1T4.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ1T4.TabIndex = 43;
            this.pcBoxJ1T4.TabStop = false;
            this.pcBoxJ1T4.Visible = false;
            // 
            // pcBoxJ1T5
            // 
            this.pcBoxJ1T5.Location = new System.Drawing.Point(486, 708);
            this.pcBoxJ1T5.Name = "pcBoxJ1T5";
            this.pcBoxJ1T5.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ1T5.TabIndex = 44;
            this.pcBoxJ1T5.TabStop = false;
            this.pcBoxJ1T5.Visible = false;
            // 
            // pcBoxJ1T6
            // 
            this.pcBoxJ1T6.Location = new System.Drawing.Point(506, 708);
            this.pcBoxJ1T6.Name = "pcBoxJ1T6";
            this.pcBoxJ1T6.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ1T6.TabIndex = 45;
            this.pcBoxJ1T6.TabStop = false;
            this.pcBoxJ1T6.Visible = false;
            // 
            // pcBoxJ1T7
            // 
            this.pcBoxJ1T7.Location = new System.Drawing.Point(526, 708);
            this.pcBoxJ1T7.Name = "pcBoxJ1T7";
            this.pcBoxJ1T7.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ1T7.TabIndex = 46;
            this.pcBoxJ1T7.TabStop = false;
            this.pcBoxJ1T7.Visible = false;
            // 
            // pcBoxJ1T8
            // 
            this.pcBoxJ1T8.Location = new System.Drawing.Point(546, 708);
            this.pcBoxJ1T8.Name = "pcBoxJ1T8";
            this.pcBoxJ1T8.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ1T8.TabIndex = 47;
            this.pcBoxJ1T8.TabStop = false;
            this.pcBoxJ1T8.Visible = false;
            // 
            // pcBoxJ1T9
            // 
            this.pcBoxJ1T9.Location = new System.Drawing.Point(566, 708);
            this.pcBoxJ1T9.Name = "pcBoxJ1T9";
            this.pcBoxJ1T9.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ1T9.TabIndex = 48;
            this.pcBoxJ1T9.TabStop = false;
            this.pcBoxJ1T9.Visible = false;
            // 
            // pcBoxJ1T10
            // 
            this.pcBoxJ1T10.Location = new System.Drawing.Point(586, 708);
            this.pcBoxJ1T10.Name = "pcBoxJ1T10";
            this.pcBoxJ1T10.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ1T10.TabIndex = 49;
            this.pcBoxJ1T10.TabStop = false;
            this.pcBoxJ1T10.Visible = false;
            // 
            // pcBoxJ1T11
            // 
            this.pcBoxJ1T11.Location = new System.Drawing.Point(606, 708);
            this.pcBoxJ1T11.Name = "pcBoxJ1T11";
            this.pcBoxJ1T11.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ1T11.TabIndex = 50;
            this.pcBoxJ1T11.TabStop = false;
            this.pcBoxJ1T11.Visible = false;
            // 
            // pcBoxJ1T12
            // 
            this.pcBoxJ1T12.Location = new System.Drawing.Point(626, 708);
            this.pcBoxJ1T12.Name = "pcBoxJ1T12";
            this.pcBoxJ1T12.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ1T12.TabIndex = 51;
            this.pcBoxJ1T12.TabStop = false;
            this.pcBoxJ1T12.Visible = false;
            // 
            // pcBoxJ2T2
            // 
            this.pcBoxJ2T2.Location = new System.Drawing.Point(846, 708);
            this.pcBoxJ2T2.Name = "pcBoxJ2T2";
            this.pcBoxJ2T2.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ2T2.TabIndex = 52;
            this.pcBoxJ2T2.TabStop = false;
            this.pcBoxJ2T2.Visible = false;
            // 
            // pcBoxJ2T3
            // 
            this.pcBoxJ2T3.Location = new System.Drawing.Point(866, 708);
            this.pcBoxJ2T3.Name = "pcBoxJ2T3";
            this.pcBoxJ2T3.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ2T3.TabIndex = 53;
            this.pcBoxJ2T3.TabStop = false;
            this.pcBoxJ2T3.Visible = false;
            // 
            // pcBoxJ2T4
            // 
            this.pcBoxJ2T4.Location = new System.Drawing.Point(886, 708);
            this.pcBoxJ2T4.Name = "pcBoxJ2T4";
            this.pcBoxJ2T4.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ2T4.TabIndex = 54;
            this.pcBoxJ2T4.TabStop = false;
            this.pcBoxJ2T4.Visible = false;
            // 
            // pcBoxJ2T5
            // 
            this.pcBoxJ2T5.Location = new System.Drawing.Point(906, 708);
            this.pcBoxJ2T5.Name = "pcBoxJ2T5";
            this.pcBoxJ2T5.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ2T5.TabIndex = 55;
            this.pcBoxJ2T5.TabStop = false;
            this.pcBoxJ2T5.Visible = false;
            // 
            // pcBoxJ2T6
            // 
            this.pcBoxJ2T6.Location = new System.Drawing.Point(926, 708);
            this.pcBoxJ2T6.Name = "pcBoxJ2T6";
            this.pcBoxJ2T6.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ2T6.TabIndex = 56;
            this.pcBoxJ2T6.TabStop = false;
            this.pcBoxJ2T6.Visible = false;
            // 
            // pcBoxJ2T7
            // 
            this.pcBoxJ2T7.Location = new System.Drawing.Point(946, 708);
            this.pcBoxJ2T7.Name = "pcBoxJ2T7";
            this.pcBoxJ2T7.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ2T7.TabIndex = 57;
            this.pcBoxJ2T7.TabStop = false;
            this.pcBoxJ2T7.Visible = false;
            // 
            // pcBoxJ2T8
            // 
            this.pcBoxJ2T8.Location = new System.Drawing.Point(966, 708);
            this.pcBoxJ2T8.Name = "pcBoxJ2T8";
            this.pcBoxJ2T8.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ2T8.TabIndex = 58;
            this.pcBoxJ2T8.TabStop = false;
            this.pcBoxJ2T8.Visible = false;
            // 
            // pcBoxJ2T9
            // 
            this.pcBoxJ2T9.Location = new System.Drawing.Point(986, 708);
            this.pcBoxJ2T9.Name = "pcBoxJ2T9";
            this.pcBoxJ2T9.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ2T9.TabIndex = 59;
            this.pcBoxJ2T9.TabStop = false;
            this.pcBoxJ2T9.Visible = false;
            // 
            // pcBoxJ2T10
            // 
            this.pcBoxJ2T10.Location = new System.Drawing.Point(1006, 708);
            this.pcBoxJ2T10.Name = "pcBoxJ2T10";
            this.pcBoxJ2T10.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ2T10.TabIndex = 60;
            this.pcBoxJ2T10.TabStop = false;
            this.pcBoxJ2T10.Visible = false;
            // 
            // pcBoxJ2T11
            // 
            this.pcBoxJ2T11.Location = new System.Drawing.Point(1026, 708);
            this.pcBoxJ2T11.Name = "pcBoxJ2T11";
            this.pcBoxJ2T11.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ2T11.TabIndex = 61;
            this.pcBoxJ2T11.TabStop = false;
            this.pcBoxJ2T11.Visible = false;
            // 
            // pcBoxJ2T12
            // 
            this.pcBoxJ2T12.Location = new System.Drawing.Point(1046, 708);
            this.pcBoxJ2T12.Name = "pcBoxJ2T12";
            this.pcBoxJ2T12.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ2T12.TabIndex = 62;
            this.pcBoxJ2T12.TabStop = false;
            this.pcBoxJ2T12.Visible = false;
            // 
            // pcBoxJ3T2
            // 
            this.pcBoxJ3T2.Location = new System.Drawing.Point(426, 738);
            this.pcBoxJ3T2.Name = "pcBoxJ3T2";
            this.pcBoxJ3T2.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ3T2.TabIndex = 63;
            this.pcBoxJ3T2.TabStop = false;
            this.pcBoxJ3T2.Visible = false;
            // 
            // pcBoxJ3T3
            // 
            this.pcBoxJ3T3.Location = new System.Drawing.Point(446, 738);
            this.pcBoxJ3T3.Name = "pcBoxJ3T3";
            this.pcBoxJ3T3.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ3T3.TabIndex = 64;
            this.pcBoxJ3T3.TabStop = false;
            this.pcBoxJ3T3.Visible = false;
            // 
            // pcBoxJ3T4
            // 
            this.pcBoxJ3T4.Location = new System.Drawing.Point(466, 738);
            this.pcBoxJ3T4.Name = "pcBoxJ3T4";
            this.pcBoxJ3T4.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ3T4.TabIndex = 65;
            this.pcBoxJ3T4.TabStop = false;
            this.pcBoxJ3T4.Visible = false;
            // 
            // pcBoxJ3T5
            // 
            this.pcBoxJ3T5.Location = new System.Drawing.Point(486, 738);
            this.pcBoxJ3T5.Name = "pcBoxJ3T5";
            this.pcBoxJ3T5.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ3T5.TabIndex = 66;
            this.pcBoxJ3T5.TabStop = false;
            this.pcBoxJ3T5.Visible = false;
            // 
            // pcBoxJ3T6
            // 
            this.pcBoxJ3T6.Location = new System.Drawing.Point(506, 738);
            this.pcBoxJ3T6.Name = "pcBoxJ3T6";
            this.pcBoxJ3T6.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ3T6.TabIndex = 67;
            this.pcBoxJ3T6.TabStop = false;
            this.pcBoxJ3T6.Visible = false;
            // 
            // pcBoxJ3T7
            // 
            this.pcBoxJ3T7.Location = new System.Drawing.Point(526, 738);
            this.pcBoxJ3T7.Name = "pcBoxJ3T7";
            this.pcBoxJ3T7.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ3T7.TabIndex = 68;
            this.pcBoxJ3T7.TabStop = false;
            this.pcBoxJ3T7.Visible = false;
            // 
            // pcBoxJ3T8
            // 
            this.pcBoxJ3T8.Location = new System.Drawing.Point(546, 738);
            this.pcBoxJ3T8.Name = "pcBoxJ3T8";
            this.pcBoxJ3T8.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ3T8.TabIndex = 69;
            this.pcBoxJ3T8.TabStop = false;
            this.pcBoxJ3T8.Visible = false;
            // 
            // pcBoxJ3T9
            // 
            this.pcBoxJ3T9.Location = new System.Drawing.Point(566, 738);
            this.pcBoxJ3T9.Name = "pcBoxJ3T9";
            this.pcBoxJ3T9.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ3T9.TabIndex = 70;
            this.pcBoxJ3T9.TabStop = false;
            this.pcBoxJ3T9.Visible = false;
            // 
            // pcBoxJ3T10
            // 
            this.pcBoxJ3T10.Location = new System.Drawing.Point(586, 738);
            this.pcBoxJ3T10.Name = "pcBoxJ3T10";
            this.pcBoxJ3T10.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ3T10.TabIndex = 71;
            this.pcBoxJ3T10.TabStop = false;
            this.pcBoxJ3T10.Visible = false;
            // 
            // pcBoxJ3T11
            // 
            this.pcBoxJ3T11.Location = new System.Drawing.Point(606, 738);
            this.pcBoxJ3T11.Name = "pcBoxJ3T11";
            this.pcBoxJ3T11.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ3T11.TabIndex = 72;
            this.pcBoxJ3T11.TabStop = false;
            this.pcBoxJ3T11.Visible = false;
            // 
            // pcBoxJ3T12
            // 
            this.pcBoxJ3T12.Location = new System.Drawing.Point(626, 738);
            this.pcBoxJ3T12.Name = "pcBoxJ3T12";
            this.pcBoxJ3T12.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ3T12.TabIndex = 73;
            this.pcBoxJ3T12.TabStop = false;
            this.pcBoxJ3T12.Visible = false;
            // 
            // pcBoxJ4T2
            // 
            this.pcBoxJ4T2.Location = new System.Drawing.Point(846, 738);
            this.pcBoxJ4T2.Name = "pcBoxJ4T2";
            this.pcBoxJ4T2.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ4T2.TabIndex = 74;
            this.pcBoxJ4T2.TabStop = false;
            this.pcBoxJ4T2.Visible = false;
            // 
            // pcBoxJ4T3
            // 
            this.pcBoxJ4T3.Location = new System.Drawing.Point(866, 738);
            this.pcBoxJ4T3.Name = "pcBoxJ4T3";
            this.pcBoxJ4T3.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ4T3.TabIndex = 75;
            this.pcBoxJ4T3.TabStop = false;
            this.pcBoxJ4T3.Visible = false;
            // 
            // pcBoxJ4T4
            // 
            this.pcBoxJ4T4.Location = new System.Drawing.Point(886, 738);
            this.pcBoxJ4T4.Name = "pcBoxJ4T4";
            this.pcBoxJ4T4.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ4T4.TabIndex = 76;
            this.pcBoxJ4T4.TabStop = false;
            this.pcBoxJ4T4.Visible = false;
            // 
            // pcBoxJ4T5
            // 
            this.pcBoxJ4T5.Location = new System.Drawing.Point(906, 738);
            this.pcBoxJ4T5.Name = "pcBoxJ4T5";
            this.pcBoxJ4T5.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ4T5.TabIndex = 77;
            this.pcBoxJ4T5.TabStop = false;
            this.pcBoxJ4T5.Visible = false;
            // 
            // pcBoxJ4T6
            // 
            this.pcBoxJ4T6.Location = new System.Drawing.Point(926, 738);
            this.pcBoxJ4T6.Name = "pcBoxJ4T6";
            this.pcBoxJ4T6.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ4T6.TabIndex = 78;
            this.pcBoxJ4T6.TabStop = false;
            this.pcBoxJ4T6.Visible = false;
            // 
            // pcBoxJ4T7
            // 
            this.pcBoxJ4T7.Location = new System.Drawing.Point(946, 738);
            this.pcBoxJ4T7.Name = "pcBoxJ4T7";
            this.pcBoxJ4T7.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ4T7.TabIndex = 79;
            this.pcBoxJ4T7.TabStop = false;
            this.pcBoxJ4T7.Visible = false;
            // 
            // pcBoxJ4T8
            // 
            this.pcBoxJ4T8.Location = new System.Drawing.Point(966, 738);
            this.pcBoxJ4T8.Name = "pcBoxJ4T8";
            this.pcBoxJ4T8.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ4T8.TabIndex = 80;
            this.pcBoxJ4T8.TabStop = false;
            this.pcBoxJ4T8.Visible = false;
            // 
            // pcBoxJ4T9
            // 
            this.pcBoxJ4T9.Location = new System.Drawing.Point(986, 738);
            this.pcBoxJ4T9.Name = "pcBoxJ4T9";
            this.pcBoxJ4T9.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ4T9.TabIndex = 81;
            this.pcBoxJ4T9.TabStop = false;
            this.pcBoxJ4T9.Visible = false;
            // 
            // pcBoxJ4T10
            // 
            this.pcBoxJ4T10.Location = new System.Drawing.Point(1006, 738);
            this.pcBoxJ4T10.Name = "pcBoxJ4T10";
            this.pcBoxJ4T10.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ4T10.TabIndex = 82;
            this.pcBoxJ4T10.TabStop = false;
            this.pcBoxJ4T10.Visible = false;
            // 
            // pcBoxJ4T11
            // 
            this.pcBoxJ4T11.Location = new System.Drawing.Point(1026, 738);
            this.pcBoxJ4T11.Name = "pcBoxJ4T11";
            this.pcBoxJ4T11.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ4T11.TabIndex = 83;
            this.pcBoxJ4T11.TabStop = false;
            this.pcBoxJ4T11.Visible = false;
            // 
            // pcBoxJ4T12
            // 
            this.pcBoxJ4T12.Location = new System.Drawing.Point(1046, 738);
            this.pcBoxJ4T12.Name = "pcBoxJ4T12";
            this.pcBoxJ4T12.Size = new System.Drawing.Size(14, 15);
            this.pcBoxJ4T12.TabIndex = 84;
            this.pcBoxJ4T12.TabStop = false;
            this.pcBoxJ4T12.Visible = false;
            // 
            // picDado1
            // 
            this.picDado1.Location = new System.Drawing.Point(55, 657);
            this.picDado1.Name = "picDado1";
            this.picDado1.Size = new System.Drawing.Size(52, 50);
            this.picDado1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picDado1.TabIndex = 92;
            this.picDado1.TabStop = false;
            this.picDado1.Visible = false;
            // 
            // picDado2
            // 
            this.picDado2.Location = new System.Drawing.Point(6, 657);
            this.picDado2.Name = "picDado2";
            this.picDado2.Size = new System.Drawing.Size(52, 50);
            this.picDado2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picDado2.TabIndex = 93;
            this.picDado2.TabStop = false;
            this.picDado2.Visible = false;
            // 
            // picDado3
            // 
            this.picDado3.Location = new System.Drawing.Point(102, 657);
            this.picDado3.Name = "picDado3";
            this.picDado3.Size = new System.Drawing.Size(52, 50);
            this.picDado3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picDado3.TabIndex = 94;
            this.picDado3.TabStop = false;
            this.picDado3.Visible = false;
            // 
            // picDado4
            // 
            this.picDado4.Location = new System.Drawing.Point(102, 708);
            this.picDado4.Name = "picDado4";
            this.picDado4.Size = new System.Drawing.Size(52, 50);
            this.picDado4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picDado4.TabIndex = 95;
            this.picDado4.TabStop = false;
            this.picDado4.Visible = false;
            // 
            // picDado5
            // 
            this.picDado5.Location = new System.Drawing.Point(6, 708);
            this.picDado5.Name = "picDado5";
            this.picDado5.Size = new System.Drawing.Size(52, 50);
            this.picDado5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picDado5.TabIndex = 96;
            this.picDado5.TabStop = false;
            this.picDado5.Visible = false;
            // 
            // picDado6
            // 
            this.picDado6.Location = new System.Drawing.Point(54, 708);
            this.picDado6.Name = "picDado6";
            this.picDado6.Size = new System.Drawing.Size(52, 50);
            this.picDado6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picDado6.TabIndex = 97;
            this.picDado6.TabStop = false;
            this.picDado6.Visible = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(9, 663);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(52, 50);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 98;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Visible = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Location = new System.Drawing.Point(55, 663);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(52, 50);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 99;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Visible = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Location = new System.Drawing.Point(102, 663);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(52, 50);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 100;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Visible = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Location = new System.Drawing.Point(9, 705);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(52, 50);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 101;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Visible = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Location = new System.Drawing.Point(55, 705);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(52, 50);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 102;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Visible = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Location = new System.Drawing.Point(102, 705);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(52, 50);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 103;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Visible = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Location = new System.Drawing.Point(9, 673);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(52, 50);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 104;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.Visible = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Location = new System.Drawing.Point(55, 673);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(52, 50);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 105;
            this.pictureBox9.TabStop = false;
            this.pictureBox9.Visible = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Location = new System.Drawing.Point(102, 673);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(52, 50);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 106;
            this.pictureBox10.TabStop = false;
            this.pictureBox10.Visible = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Location = new System.Drawing.Point(6, 720);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(52, 50);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11.TabIndex = 107;
            this.pictureBox11.TabStop = false;
            this.pictureBox11.Visible = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.Location = new System.Drawing.Point(54, 720);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(52, 50);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox12.TabIndex = 108;
            this.pictureBox12.TabStop = false;
            this.pictureBox12.Visible = false;
            // 
            // pictureBox13
            // 
            this.pictureBox13.Location = new System.Drawing.Point(102, 720);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(52, 50);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox13.TabIndex = 109;
            this.pictureBox13.TabStop = false;
            this.pictureBox13.Visible = false;
            // 
            // pictureBox14
            // 
            this.pictureBox14.Location = new System.Drawing.Point(9, 673);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(52, 50);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox14.TabIndex = 110;
            this.pictureBox14.TabStop = false;
            this.pictureBox14.Visible = false;
            // 
            // pictureBox15
            // 
            this.pictureBox15.Location = new System.Drawing.Point(55, 673);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(52, 50);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox15.TabIndex = 111;
            this.pictureBox15.TabStop = false;
            this.pictureBox15.Visible = false;
            // 
            // pictureBox16
            // 
            this.pictureBox16.Location = new System.Drawing.Point(99, 673);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(52, 50);
            this.pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox16.TabIndex = 112;
            this.pictureBox16.TabStop = false;
            this.pictureBox16.Visible = false;
            // 
            // pictureBox17
            // 
            this.pictureBox17.Location = new System.Drawing.Point(9, 722);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(52, 50);
            this.pictureBox17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox17.TabIndex = 113;
            this.pictureBox17.TabStop = false;
            this.pictureBox17.Visible = false;
            // 
            // pictureBox18
            // 
            this.pictureBox18.Location = new System.Drawing.Point(55, 722);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(52, 50);
            this.pictureBox18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox18.TabIndex = 114;
            this.pictureBox18.TabStop = false;
            this.pictureBox18.Visible = false;
            // 
            // pictureBox19
            // 
            this.pictureBox19.Location = new System.Drawing.Point(99, 722);
            this.pictureBox19.Name = "pictureBox19";
            this.pictureBox19.Size = new System.Drawing.Size(52, 50);
            this.pictureBox19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox19.TabIndex = 115;
            this.pictureBox19.TabStop = false;
            this.pictureBox19.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(247, 214);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 116;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(247, 245);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 13);
            this.label2.TabIndex = 117;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(247, 282);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 13);
            this.label3.TabIndex = 118;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(247, 310);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 13);
            this.label4.TabIndex = 119;
            // 
            // pictureBox20
            // 
            this.pictureBox20.Location = new System.Drawing.Point(36, 428);
            this.pictureBox20.Name = "pictureBox20";
            this.pictureBox20.Size = new System.Drawing.Size(52, 50);
            this.pictureBox20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox20.TabIndex = 129;
            this.pictureBox20.TabStop = false;
            this.pictureBox20.Visible = false;
            // 
            // pictureBox21
            // 
            this.pictureBox21.Location = new System.Drawing.Point(103, 428);
            this.pictureBox21.Name = "pictureBox21";
            this.pictureBox21.Size = new System.Drawing.Size(52, 50);
            this.pictureBox21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox21.TabIndex = 130;
            this.pictureBox21.TabStop = false;
            this.pictureBox21.Visible = false;
            // 
            // pictureBox22
            // 
            this.pictureBox22.Location = new System.Drawing.Point(195, 428);
            this.pictureBox22.Name = "pictureBox22";
            this.pictureBox22.Size = new System.Drawing.Size(52, 50);
            this.pictureBox22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox22.TabIndex = 132;
            this.pictureBox22.TabStop = false;
            this.pictureBox22.Visible = false;
            // 
            // pictureBox23
            // 
            this.pictureBox23.Location = new System.Drawing.Point(263, 428);
            this.pictureBox23.Name = "pictureBox23";
            this.pictureBox23.Size = new System.Drawing.Size(52, 50);
            this.pictureBox23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox23.TabIndex = 131;
            this.pictureBox23.TabStop = false;
            this.pictureBox23.Visible = false;
            // 
            // pictureBox24
            // 
            this.pictureBox24.Location = new System.Drawing.Point(36, 498);
            this.pictureBox24.Name = "pictureBox24";
            this.pictureBox24.Size = new System.Drawing.Size(52, 50);
            this.pictureBox24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox24.TabIndex = 134;
            this.pictureBox24.TabStop = false;
            this.pictureBox24.Visible = false;
            // 
            // pictureBox25
            // 
            this.pictureBox25.Location = new System.Drawing.Point(103, 498);
            this.pictureBox25.Name = "pictureBox25";
            this.pictureBox25.Size = new System.Drawing.Size(52, 50);
            this.pictureBox25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox25.TabIndex = 133;
            this.pictureBox25.TabStop = false;
            this.pictureBox25.Visible = false;
            // 
            // pictureBox26
            // 
            this.pictureBox26.Location = new System.Drawing.Point(195, 498);
            this.pictureBox26.Name = "pictureBox26";
            this.pictureBox26.Size = new System.Drawing.Size(52, 50);
            this.pictureBox26.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox26.TabIndex = 136;
            this.pictureBox26.TabStop = false;
            this.pictureBox26.Visible = false;
            // 
            // pictureBox27
            // 
            this.pictureBox27.Location = new System.Drawing.Point(263, 498);
            this.pictureBox27.Name = "pictureBox27";
            this.pictureBox27.Size = new System.Drawing.Size(52, 50);
            this.pictureBox27.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox27.TabIndex = 135;
            this.pictureBox27.TabStop = false;
            this.pictureBox27.Visible = false;
            // 
            // lblC1
            // 
            this.lblC1.AutoSize = true;
            this.lblC1.Location = new System.Drawing.Point(3, 412);
            this.lblC1.Name = "lblC1";
            this.lblC1.Size = new System.Drawing.Size(75, 13);
            this.lblC1.TabIndex = 137;
            this.lblC1.Text = "Combinação 1";
            // 
            // lblC2
            // 
            this.lblC2.AutoSize = true;
            this.lblC2.Location = new System.Drawing.Point(3, 482);
            this.lblC2.Name = "lblC2";
            this.lblC2.Size = new System.Drawing.Size(75, 13);
            this.lblC2.TabIndex = 139;
            this.lblC2.Text = "Combinação 2";
            // 
            // lblC3
            // 
            this.lblC3.AutoSize = true;
            this.lblC3.Location = new System.Drawing.Point(3, 549);
            this.lblC3.Name = "lblC3";
            this.lblC3.Size = new System.Drawing.Size(75, 13);
            this.lblC3.TabIndex = 144;
            this.lblC3.Text = "Combinação 3";
            // 
            // pictureBox28
            // 
            this.pictureBox28.Location = new System.Drawing.Point(36, 565);
            this.pictureBox28.Name = "pictureBox28";
            this.pictureBox28.Size = new System.Drawing.Size(52, 50);
            this.pictureBox28.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox28.TabIndex = 143;
            this.pictureBox28.TabStop = false;
            this.pictureBox28.Visible = false;
            // 
            // pictureBox29
            // 
            this.pictureBox29.Location = new System.Drawing.Point(103, 565);
            this.pictureBox29.Name = "pictureBox29";
            this.pictureBox29.Size = new System.Drawing.Size(52, 50);
            this.pictureBox29.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox29.TabIndex = 142;
            this.pictureBox29.TabStop = false;
            this.pictureBox29.Visible = false;
            // 
            // pictureBox30
            // 
            this.pictureBox30.Location = new System.Drawing.Point(195, 565);
            this.pictureBox30.Name = "pictureBox30";
            this.pictureBox30.Size = new System.Drawing.Size(52, 50);
            this.pictureBox30.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox30.TabIndex = 141;
            this.pictureBox30.TabStop = false;
            this.pictureBox30.Visible = false;
            // 
            // pictureBox31
            // 
            this.pictureBox31.Location = new System.Drawing.Point(263, 565);
            this.pictureBox31.Name = "pictureBox31";
            this.pictureBox31.Size = new System.Drawing.Size(52, 50);
            this.pictureBox31.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox31.TabIndex = 140;
            this.pictureBox31.TabStop = false;
            this.pictureBox31.Visible = false;
            // 
            // timer1
            // 
            this.timer1.Interval = 5000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // lblERRO
            // 
            this.lblERRO.AutoSize = true;
            this.lblERRO.Location = new System.Drawing.Point(708, 44);
            this.lblERRO.Name = "lblERRO";
            this.lblERRO.Size = new System.Drawing.Size(35, 13);
            this.lblERRO.TabIndex = 148;
            this.lblERRO.Text = "label8";
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(406, 76);
            this.textBox9.Multiline = true;
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(214, 151);
            this.textBox9.TabIndex = 149;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(701, 0);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(100, 20);
            this.textBox10.TabIndex = 150;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(807, 0);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(100, 20);
            this.textBox11.TabIndex = 151;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(913, 0);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(100, 20);
            this.textBox12.TabIndex = 152;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(1019, 0);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(100, 20);
            this.textBox13.TabIndex = 153;
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(195, 27);
            this.textBox20.Multiline = true;
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(205, 117);
            this.textBox20.TabIndex = 167;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1200, 713);
            this.Controls.Add(this.textBox20);
            this.Controls.Add(this.textBox13);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.lblERRO);
            this.Controls.Add(this.lblC3);
            this.Controls.Add(this.pictureBox28);
            this.Controls.Add(this.pictureBox29);
            this.Controls.Add(this.pictureBox30);
            this.Controls.Add(this.pictureBox31);
            this.Controls.Add(this.lblC2);
            this.Controls.Add(this.lblC1);
            this.Controls.Add(this.pictureBox26);
            this.Controls.Add(this.pictureBox27);
            this.Controls.Add(this.pictureBox24);
            this.Controls.Add(this.pictureBox25);
            this.Controls.Add(this.pictureBox22);
            this.Controls.Add(this.pictureBox23);
            this.Controls.Add(this.pictureBox21);
            this.Controls.Add(this.pictureBox20);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox19);
            this.Controls.Add(this.pictureBox18);
            this.Controls.Add(this.pictureBox17);
            this.Controls.Add(this.pictureBox16);
            this.Controls.Add(this.pictureBox15);
            this.Controls.Add(this.pictureBox14);
            this.Controls.Add(this.pictureBox13);
            this.Controls.Add(this.pictureBox12);
            this.Controls.Add(this.pictureBox11);
            this.Controls.Add(this.pictureBox10);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.picDado6);
            this.Controls.Add(this.picDado5);
            this.Controls.Add(this.picDado4);
            this.Controls.Add(this.picDado3);
            this.Controls.Add(this.picDado2);
            this.Controls.Add(this.picDado1);
            this.Controls.Add(this.pcBoxJ4T12);
            this.Controls.Add(this.pcBoxJ4T11);
            this.Controls.Add(this.pcBoxJ4T10);
            this.Controls.Add(this.pcBoxJ4T9);
            this.Controls.Add(this.pcBoxJ4T8);
            this.Controls.Add(this.pcBoxJ4T7);
            this.Controls.Add(this.pcBoxJ4T6);
            this.Controls.Add(this.pcBoxJ4T5);
            this.Controls.Add(this.pcBoxJ4T4);
            this.Controls.Add(this.pcBoxJ4T3);
            this.Controls.Add(this.pcBoxJ4T2);
            this.Controls.Add(this.pcBoxJ3T12);
            this.Controls.Add(this.pcBoxJ3T11);
            this.Controls.Add(this.pcBoxJ3T10);
            this.Controls.Add(this.pcBoxJ3T9);
            this.Controls.Add(this.pcBoxJ3T8);
            this.Controls.Add(this.pcBoxJ3T7);
            this.Controls.Add(this.pcBoxJ3T6);
            this.Controls.Add(this.pcBoxJ3T5);
            this.Controls.Add(this.pcBoxJ3T4);
            this.Controls.Add(this.pcBoxJ3T3);
            this.Controls.Add(this.pcBoxJ3T2);
            this.Controls.Add(this.pcBoxJ2T12);
            this.Controls.Add(this.pcBoxJ2T11);
            this.Controls.Add(this.pcBoxJ2T10);
            this.Controls.Add(this.pcBoxJ2T9);
            this.Controls.Add(this.pcBoxJ2T8);
            this.Controls.Add(this.pcBoxJ2T7);
            this.Controls.Add(this.pcBoxJ2T6);
            this.Controls.Add(this.pcBoxJ2T5);
            this.Controls.Add(this.pcBoxJ2T4);
            this.Controls.Add(this.pcBoxJ2T3);
            this.Controls.Add(this.pcBoxJ2T2);
            this.Controls.Add(this.pcBoxJ1T12);
            this.Controls.Add(this.pcBoxJ1T11);
            this.Controls.Add(this.pcBoxJ1T10);
            this.Controls.Add(this.pcBoxJ1T9);
            this.Controls.Add(this.pcBoxJ1T8);
            this.Controls.Add(this.pcBoxJ1T7);
            this.Controls.Add(this.pcBoxJ1T6);
            this.Controls.Add(this.pcBoxJ1T5);
            this.Controls.Add(this.pcBoxJ1T4);
            this.Controls.Add(this.pcBoxJ1T3);
            this.Controls.Add(this.pcBoxJ1T2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.lblDLL);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.listBox2);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = ".";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ1T2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ1T3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ1T4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ1T5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ1T6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ1T7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ1T8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ1T9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ1T10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ1T11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ1T12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ2T2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ2T3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ2T4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ2T5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ2T6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ2T7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ2T8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ2T9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ2T10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ2T11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ2T12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ3T2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ3T3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ3T4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ3T5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ3T6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ3T7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ3T8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ3T9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ3T10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ3T11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ3T12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ4T2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ4T3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ4T4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ4T5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ4T6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ4T7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ4T8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ4T9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ4T10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ4T11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcBoxJ4T12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDado1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDado2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDado3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDado4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDado5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDado6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox31)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.ToolStripMenuItem arquivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem restaurarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem maximizarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem minimizarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fecharToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listarPartidasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listarJogadoreToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem criarPartidaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem entrarEmUmaPartidaToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem criarPartidaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem entrarEmUmaPartidaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem sobreToolStripMenuItem;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.ToolStripMenuItem versãoDLLToolStripMenuItem;
        private System.Windows.Forms.ErrorProvider errorProvider;
        private System.Windows.Forms.ToolStripMenuItem iniciarPartidaToolStripMenuItem;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;

        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label lblDLL;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.PictureBox pcBoxJ1T3;
        private System.Windows.Forms.PictureBox pcBoxJ1T2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pcBoxJ1T12;
        private System.Windows.Forms.PictureBox pcBoxJ1T11;
        private System.Windows.Forms.PictureBox pcBoxJ1T10;
        private System.Windows.Forms.PictureBox pcBoxJ1T9;
        private System.Windows.Forms.PictureBox pcBoxJ1T8;
        private System.Windows.Forms.PictureBox pcBoxJ1T7;
        private System.Windows.Forms.PictureBox pcBoxJ1T6;
        private System.Windows.Forms.PictureBox pcBoxJ1T5;
        private System.Windows.Forms.PictureBox pcBoxJ1T4;
        private System.Windows.Forms.PictureBox pcBoxJ2T2;
        private System.Windows.Forms.PictureBox pcBoxJ2T3;
        private System.Windows.Forms.PictureBox pcBoxJ2T4;
        private System.Windows.Forms.PictureBox pcBoxJ2T5;
        private System.Windows.Forms.PictureBox pcBoxJ2T6;
        private System.Windows.Forms.PictureBox pcBoxJ2T7;
        private System.Windows.Forms.PictureBox pcBoxJ2T8;
        private System.Windows.Forms.PictureBox pcBoxJ2T9;
        private System.Windows.Forms.PictureBox pcBoxJ2T10;
        private System.Windows.Forms.PictureBox pcBoxJ2T11;
        private System.Windows.Forms.PictureBox pcBoxJ2T12;
        private System.Windows.Forms.PictureBox pcBoxJ3T12;
        private System.Windows.Forms.PictureBox pcBoxJ3T11;
        private System.Windows.Forms.PictureBox pcBoxJ3T10;
        private System.Windows.Forms.PictureBox pcBoxJ3T9;
        private System.Windows.Forms.PictureBox pcBoxJ3T8;
        private System.Windows.Forms.PictureBox pcBoxJ3T7;
        private System.Windows.Forms.PictureBox pcBoxJ3T6;
        private System.Windows.Forms.PictureBox pcBoxJ3T5;
        private System.Windows.Forms.PictureBox pcBoxJ3T4;
        private System.Windows.Forms.PictureBox pcBoxJ3T3;
        private System.Windows.Forms.PictureBox pcBoxJ3T2;
        private System.Windows.Forms.PictureBox pcBoxJ4T12;
        private System.Windows.Forms.PictureBox pcBoxJ4T11;
        private System.Windows.Forms.PictureBox pcBoxJ4T10;
        private System.Windows.Forms.PictureBox pcBoxJ4T9;
        private System.Windows.Forms.PictureBox pcBoxJ4T8;
        private System.Windows.Forms.PictureBox pcBoxJ4T7;
        private System.Windows.Forms.PictureBox pcBoxJ4T6;
        private System.Windows.Forms.PictureBox pcBoxJ4T5;
        private System.Windows.Forms.PictureBox pcBoxJ4T4;
        private System.Windows.Forms.PictureBox pcBoxJ4T3;
        private System.Windows.Forms.PictureBox pcBoxJ4T2;
        private System.Windows.Forms.PictureBox picDado6;
        private System.Windows.Forms.PictureBox picDado5;
        private System.Windows.Forms.PictureBox picDado4;
        private System.Windows.Forms.PictureBox picDado3;
        private System.Windows.Forms.PictureBox picDado2;
        private System.Windows.Forms.PictureBox picDado1;
        private System.Windows.Forms.PictureBox pictureBox19;
        private System.Windows.Forms.PictureBox pictureBox18;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox26;
        private System.Windows.Forms.PictureBox pictureBox27;
        private System.Windows.Forms.PictureBox pictureBox24;
        private System.Windows.Forms.PictureBox pictureBox25;
        private System.Windows.Forms.PictureBox pictureBox22;
        private System.Windows.Forms.PictureBox pictureBox23;
        private System.Windows.Forms.PictureBox pictureBox21;
        private System.Windows.Forms.PictureBox pictureBox20;
        private System.Windows.Forms.Label lblC2;
        private System.Windows.Forms.Label lblC1;
        private System.Windows.Forms.Label lblC3;
        private System.Windows.Forms.PictureBox pictureBox28;
        private System.Windows.Forms.PictureBox pictureBox29;
        private System.Windows.Forms.PictureBox pictureBox30;
        private System.Windows.Forms.PictureBox pictureBox31;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lblERRO;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox20;
    }
}

