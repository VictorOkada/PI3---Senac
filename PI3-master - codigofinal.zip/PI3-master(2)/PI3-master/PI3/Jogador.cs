﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PI3
{
   class Jogador
    {
        public int IdJogador { get; set; }
        public string Nome { get; set; }
        public string Senha { get; set; }

    }
}
