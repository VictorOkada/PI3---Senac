﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PI3
{
    class Tabuleiro
    {
        public int idJogador { get; set; }

        public int Trilha { get; set; }
        public int Posicao { get; set; }

        public string Tipo { get; set; }
    }




}
