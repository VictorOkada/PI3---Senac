﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PI3
{
    public class Dado
    {
        public int IdDado { get; set; }
        public int Dado1 { get; set; }
        public int Dado2 { get; set; }
        public int Dado3 { get; set; }
        public int Dado4 { get; set; }
    }
}
